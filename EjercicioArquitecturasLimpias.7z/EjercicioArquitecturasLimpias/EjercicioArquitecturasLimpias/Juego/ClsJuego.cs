﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EjercicioArquitecturasLimpias.Juego
{
	public class ClsJuego: ClsVideoJuego, ClsJugador, IJugador
	{
	}
}
