﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EjercicioArquitecturasLimpias
{
	public class ClsJugador : ClsPersona, IJugador
	{
		private string alias;
		private string email;
		private string ciudad;
		private string pais;

		public ClsJugador(int identificacion, string nombre) : base(identificacion, nombre)
		{
		}

		public string Alias { get => alias; set => alias = value; }
		public string Email { get => email; set => email = value; }
		public string Ciudad { get => ciudad; set => ciudad = value; }
		public string Pais { get => pais; set => pais = value; }

		public void RegistrarJugador()
		{
			Console.WriteLine("Usuario con identificación: " + getIdentificacion() + " y nombre " + getNombre() + " esta registrado con el alias => " + alias);
		}
	}
}
