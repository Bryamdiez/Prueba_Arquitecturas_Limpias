﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EjercicioArquitecturasLimpias
{
	interface IJugador
	{
		void RegistrarJugador();
	}
}
