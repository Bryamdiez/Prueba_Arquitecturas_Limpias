﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EjercicioArquitecturasLimpias
{
	public class ClsPersona
	{
		private int identificacion;
		private string nombrePersona;

		public ClsPersona(int identificacion, string nombre)
		{
			this.identificacion = identificacion;
			this.nombrePersona = nombre;
		}

		public int getIdentificacion()
		{
			return identificacion;
		}

		public string getNombre()
		{
			return nombrePersona;
		}

	}
}
