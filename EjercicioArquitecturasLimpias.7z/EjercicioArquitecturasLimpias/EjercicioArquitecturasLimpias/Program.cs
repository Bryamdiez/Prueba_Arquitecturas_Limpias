﻿using System;
using System.Collections.Generic;

namespace EjercicioArquitecturasLimpias
{
	class Program
	{
		static void Main(string[] args)
		{
			ClsJugador jugador = new ClsJugador(1, "Sutanito Perez");
			jugador.Alias = "MiAlias";
			jugador.Email = "correo@yopmail.com";
			jugador.Ciudad = "Medellin";
			jugador.Pais = "Colombia";
			jugador.RegistrarJugador();

			Console.WriteLine("---------------------------------------------------");

			List<ClsVideoJuego> lstVideoJuegos = new List<ClsVideoJuego>() { new ClsVideoJuego(321, "Fornite", "Batle Royal", "Competitiva"), new ClsVideoJuego(987, "FIFA", "Deportes", "Individual"};
			ClsVideoJuego videoJuego = new ClsVideoJuego();
			videoJuego.ListarVideoJuegos(lstVideoJuegos);

			Console.WriteLine("---------------------------------------------------");

		}
	}
}
