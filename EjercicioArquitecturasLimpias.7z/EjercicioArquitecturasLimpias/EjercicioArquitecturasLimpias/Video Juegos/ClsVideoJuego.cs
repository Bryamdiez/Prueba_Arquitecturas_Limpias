﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EjercicioArquitecturasLimpias
{
	public class ClsVideoJuego: IVideoJuego
	{
		private int id;
		private string nombreJuego;
		private string descripcion;
		private string modalidad;
		List<ClsVideoJuego> lstVideoJuegos = new List<ClsVideoJuego>();

		public ClsVideoJuego()
		{
		}

		public ClsVideoJuego(int id, string nombreJuego, string descripcion, string modalidad)
		{
			this.id = id;
			this.nombreJuego = nombreJuego;
			this.descripcion = descripcion;
			this.modalidad = modalidad;			
		}

		public void ListarVideoJuegos(List<ClsVideoJuego> lista)
		{
			foreach (ClsVideoJuego lst in lista)
			{
				Console.WriteLine("Juegos disponibles => " + lst.nombreJuego);
			}
		}
	}
}
