﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EjercicioArquitecturasLimpias
{
	interface IVideoJuego
	{
		void ListarVideoJuegos(List<ClsVideoJuego> lista);

	}
}
